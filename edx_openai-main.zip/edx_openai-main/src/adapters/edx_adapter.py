class EdxAdapter:
    """
    EDX адаптер - логик получения данных с EDX API
    """
    def get_data(self, text) -> str:
        """
        :param text: ???
        :return: ???
        """
        # Логика получения данных с Edx API (требует решения)
        return text